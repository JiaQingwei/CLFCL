
function TJS=computeTJS(X,J,R_L,H)
[n,l]=size(J);
%Y1(J==0)=-1;
%R_L=cell(l,1);%�������ǩȷ���ĵȼ���

   for s=1:l
      S=R_L{s};
%       temp= find(Y1(:,s)==1);
%       temp1= find(Y1(:,s)==0);
      temp2= find(J(:,s)==0);
%       S(temp,temp)=1;
%       S(temp1,temp1)=1;
      for t=1:size(temp2,1)
          for k=1:n
            S(temp2(t),k)=(exp(-L2_distance(X(temp2(t),:)',X(k,:)'))+exp(-L2_distance(H(temp2(t),:)',H(k,:)')))/2;
            S(k,temp2(t))=S(temp2(t),k);
          end
      end
      R_L{s}=S;
   end
   tiaojianshang=zeros(l,l);
   for s=1:l
       for t=1:l
          % tiaojianshang(s,t)= -sum(sum(min(R_L{s},R_L{t})))/sum(sum(R_L{t}))*log(sum(sum(min(R_L{s},R_L{t})))/sum(sum(R_L{t})));
           tiaojianshang(s,t)= -ones(1,n)*(min(R_L{s},R_L{t})*ones(n,1))/(ones(1,n)*(R_L{s}*ones(n,1)))*log(ones(1,n)*(min(R_L{s},R_L{t})*ones(n,1))/(ones(1,n)*(R_L{s}*ones(n,1))));
       end
   end
        MIN=min(min(tiaojianshang));
        MAX=max(max(tiaojianshang));
      tiaojianshang=(tiaojianshang- MIN)/MAX;
%     for s=1:l
%        for t=1:l
%            tiaojianshang(s,t)= (tiaojianshang(s,t)-MIN)/MAX;
%        end
%     end
   TJS=ones(l,l)-tiaojianshang;
end