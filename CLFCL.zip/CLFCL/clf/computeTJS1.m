
function TJS=computeTJS1(X,J,R_L,H,Y1)
[n,l]=size(J);
Y1(J==0)=-1;
%R_L=cell(l,1);%�������ǩȷ���ĵȼ���
S1=(exp(-L2_distance(X',X')/2)+exp(-L2_distance(H',H')/2))/2;
   for s=1:l
      S=R_L{s};
      temp= find(Y1(:,s)==1);
      temp1= find(Y1(:,s)==0);
      temp2= find(J(:,s)==0);
      S(temp2,:)=S1(temp2,:);
      S(:,temp2,:)=S1(:,temp2);
      S(temp,temp)=1;
      S(temp1,temp1)=1;
      R_L{s}=S;
   end
   tiaojianshang=zeros(l,l);
   for s=1:l
       tiaojianshang(s,s)=log(n^2/(ones(1,n)*(R_L{s}*ones(n,1))));
       for t=s+1:l
           %tiaojianshang(s,t)= -sum(sum(min(R_L{s},R_L{t})))/sum(sum(R_L{s}))*log(sum(sum(min(R_L{s},R_L{t})))/sum(sum(R_L{s})));
           %tiaojianshang(s,t)= -ones(1,n)*(min(R_L{s},R_L{t})*ones(n,1))/(ones(1,n)*(R_L{s}*ones(n,1))*ones(1,n)*(R_L{t}*ones(n,1)))*log(ones(1,n)*(min(R_L{s},R_L{t})*ones(n,1))/(ones(1,n)*(R_L{s}*ones(n,1))*ones(1,n)*(R_L{t}*ones(n,1))));
           tiaojianshang(s,t)= log(n^2*ones(1,n)*(min(R_L{s},R_L{t})*ones(n,1))/(ones(1,n)*(R_L{s}*ones(n,1))*ones(1,n)*(R_L{t}*ones(n,1))));
           tiaojianshang(t,s)= tiaojianshang(s,t);

       end
   end
        MIN=min(min(tiaojianshang));
        MAX=max(max(tiaojianshang));
      tiaojianshang=(tiaojianshang- MIN)/(MAX+eps);
%     for s=1:l
%        for t=1:l
%            tiaojianshang(s,t)= (tiaojianshang(s,t)-MIN)/MAX;
%        end
%     end
S=tiaojianshang;
D=diag(S*ones(l,1)+eps);
D1=diag(diag(D.^(-1/2)));
D1=real(D1);
S=D1*S*D1;
   TJS=S;
   Y1(J==0)=0;
end